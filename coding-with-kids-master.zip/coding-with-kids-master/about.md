
# About 

This documentation project is **not** 
meant to be an exhaustive look at coding
with kids.

Rather it was used as the basis 
for a video course about learning
how to use[Read The Docs](http://readthedocs.org).

`Hopefully` you take this in the spirit that 
in which it was written and pardon any 
exclusions or inaccuracies.

## Opinions
Comments are mine, not anyone else's.  Etc.