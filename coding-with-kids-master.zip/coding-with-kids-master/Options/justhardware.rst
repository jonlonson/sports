
Just Hardware
+++++++++++++

Key Goals
=========

Options
=======

Arduino
-------
Arduino is an open source electronics 
platform that is great for both 
adults and kids.

https://www.arduino.cc/

Snap Circuits
-------------
`Snap Circuits <http://www.snapcircuits.net/>`_
is a great electronics learning platform
consisting of plastic board and 
electronics components that you snap
together based on project guides to 
learn basic electronics concepts.

Project Bloks (in development)
------------------------------
Project Bloks is on the web 
at https://projectbloks.withgoogle.com/ and
is a new project from Google that is still 
being developed but looks pretty awesome
if you have younger kids that want to learn
logic and flow.