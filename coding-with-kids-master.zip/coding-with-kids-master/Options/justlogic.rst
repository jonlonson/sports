
Just Logic
++++++++++
All of the options below involve no 
screens at all -- they are simply physical
objects and some problems to be solved.

Key Goals
======================
The main goals regarding ``logic`` that you 
might pursue with some of the options below 
are as follows:

* **Understand** basic logic
* *Use available* options
* ``Apply`` problem solving techniques
* Have fun!  :)

Options
=======

CodeMaster
----------

Robot Turtles 
-------------

Primo / Cubetto
---------------